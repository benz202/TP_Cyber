<?php
// Database connection parameters
$host = 'localhost'; // Change this if your database is hosted elsewhere
$username = 'root'; // Change this to your database username
$password = ''; // Change this to your database password
$database = 'security_project'; // Change this to your database name

try {
    $conn = new PDO("mysql:host=$host;dbname=$database", $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    echo "Connexion réussie";
} catch(PDOException $e) {
    echo "Erreur de connexion : " . $e->getMessage();
}

if (!isset($_SESSION['csrf_token'])) {
  $_SESSION['csrf_token'] = bin2hex(random_bytes(32)); 
}

if (!hash_equals($_SESSION['csrf_token'], $_POST['csrf_token'])) {
  die("Erreur CSRF : Le token CSRF est invalide.");
}

// Check if the form is submitted
if (isset($_POST['submit'])) {
    // Retrieve username and password from the form
    $username = $_POST['username'];
    $password = $_POST['password'];

    // Hash the password
    $hashed_password = password_hash($password, PASSWORD_DEFAULT);

    // Use prepared statements to prevent SQL injection
    $stmt = $conn->prepare("INSERT INTO users (username, password) VALUES (?, ?)");
    if ($stmt->execute([$username, $hashed_password])) {
        echo "New record inserted successfully";
    } else {
        echo "Error: " . $stmt->errorInfo()[2]; // Retrieve error information
    }
}
?>
